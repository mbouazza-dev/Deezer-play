# Deezer-play
Program allowing playlist completion via neural network and use of the word2vec model 
